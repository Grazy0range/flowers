<?php
// Text
$_['text_footer']  = '<a href="https://ocstore.com/">ocStore</a> &copy; 2009-' . date('Y') . ' All Rights Reserved.';
$_['text_version'] = 'Version %s';